"""
Section C: Code Challenge

    Option 3: Resistor Networks


        Create a function that takes a nested network(parallel and series) as a 
        string and returns the equivalent resistance of the 
        network.Round results to the nearest tenth of an ohm.

        Lnaguage used : Python
        Auther: L.E MOHLABANE
"""
#function to takes nested networks
def resist(network):
    
     #function to resolve the nested networks in to series and parallel
    #There after it get the results of the equivalent circuit
	def res(net):
       
        #Get the sum of the resistance in series
		if type(net) == tuple: return sum(res(sub) for sub in net)
        
        #Get the sum of the resisyance in parallel 
		if type(net) == list: return 1/sum(1/res(sub) for sub in net)

		return net
    #return the equivalent of the circuit rounded the nearest tenth 
	return round(res(eval(network)),1)

#Print the results to the console 
print(resist("(2, 3, 6),[2,2]"),"ohm(s)");
print(resist("(4,6),[1,2,4],2"),"ohm(s)");
print(resist("6,[2,12,8],8, (2, 2)"),"ohm(s)");