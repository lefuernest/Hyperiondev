# Section C: Code Challenge
### Instructions

1.      We suggest that you implement your solution in either Python, Java, Ruby or TypeScript.
1.      You're more than welcome to use any programming language and paradigm that you fancy as long as your solution is idiomatic.
1.      You are required to include a test suite for your solution.
1.      Please include all instructions and scripts necessary to build, test and run your solution on Linux, macOS and Windows operating systems.
1.      Please include a Markdown report that specifies and justifies the worst-case space complexity of your solution.
1.       Please attempt any one option of the alternatives available from below:

# Solution
 > The code presented below is the solution to the above  instructions 
 > To run the program on windows/linux/MacOs, choose one of the two method below of which i assume they are relatively easy to follow. 
 > ### **First Method** 
 > * Open CMD/Terminal and navigate to sectionC folder:
 > * 'cd\sectionCb' then in terminal type 'python resistor_net.py'

> ### **Alternate method**
>
> If you find it cumbersome to write python in the > > terminal every time you run the script, follow the > procedure below:
>
> * Prepend #! /usr/bin/python with your script.
> * Run the following command in your terminal to 
>make the script executable: chmod +x resistor_net.py
> * Now, ​simply type ./resistor_net.py to run the executable script.

