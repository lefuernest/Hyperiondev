# Section B: Projects
## Instructions

> * Please share a GitHub URL to a project you're most proud of.
> * You may include the link in the repository you are submitting for the test.
> * You may have completed it in the past or it may be freshly completed for this test.
> * The project could be in any domain using any technology stack.

## Solution
find the link below to the project in quetion, the link should redirect you to the GitHub repository where the project can be found.

![GitHub Link to my Data science project i did through udacity](https://github.com/lefuernest/AI-Programming.git)