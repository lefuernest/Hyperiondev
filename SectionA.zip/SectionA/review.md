# Dear student

Congratulations on embarking on this very exciting project on your very first submit, it is never an easy task.We hope you learning quite as much in the build up of this project.

Below find where yoou can improve your coding based on the following:

* Correctness
* Efficiency
* Style
* Documentation

## Correctness
```TypeScript
// Function: Caesar Cipher
const caesar_cipher<T> = (string: T, shift: string) => {
```
>  Looking at the code snippet above
> * The method definition on **line 16** is not well defined,Hence, the errors on your code occuring through out the method.
> * i'll suggest you go with the definition below 
```TypeScript
    //suggested caesar_function
    export const carsar_cipher = (string : string, shfit: number) => {}
```

```TypeScript

    //printing the output to terminal to test for correct output
    //should print THE QUICK BROWN DOG JUMPED OVER THE LAZY FOX.
    print(caesar_cipher('GUR DHVPX OEBJA QBT WHZCRQ BIRE GUR YNML SBK.', 39));
```
> * Looking at code from **line 62** above your method is unable to print due to the method print used.
> * I suggest you use the _console.log()_ to display the result 

## Efficiency

in terms of efficiency well done for writing efficient code saving the run time of the program.

## Style
The TypeScript coding style you used is readable and understandable.
## Documentation
Job well done again for writing a readable code by putting comments on it.